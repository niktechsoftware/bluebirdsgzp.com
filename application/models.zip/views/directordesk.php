<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	<br>
        	<br>
        	<br>
        	<br>
        	
        	<br>
        	<br>
        	<br>
        	
        	<table>
        	<tr><td>
 <img src="<?php echo base_url();?>assets/images/chair.jpg"  height="200" width="200"></a></td>
         <td> <p  style="margin-left:5em;">  The motive behind the establishment of Blue Bird's International School is to educate the children of the locality through discipline and by making
children, sensitive to the finer aspects of life, to meet the challenges in the future and to comptete with the modern world.
The Blue Bird's International School is just beginning its first academic session 2013-14. The School aims at developing essential personality, positive
attitude, skills and behaviour in children. The overall development of the children physically, morally and ethically is our sole aim. Our objective is to train the
students to realize their social responsibilities and acquire leadership.</p>
</td></tr>
<tr><td></td><td><p style="margin-left:5em; ">Chairman<br> Blue Birds International School</p></td></tr>
                
			</table>
			
        	<br>
        	<br>
        	<br>
        	<br>
        	<br>
        	<br>
        	<br>	
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
