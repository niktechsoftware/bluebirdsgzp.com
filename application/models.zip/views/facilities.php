<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	<br>
        	<br>
        
        	<table>
        	<tr>
         <td> 
         <h1 style="margin-left:7em;">Facilities</h1>
         
         
         
           </div><br />
    
    <div>
     <div>
	<table cellspacing="2" cellpadding="3" rules="all" id="ContentPlaceHolder1_DetailsView1" style="background-color:#DEBA84;border-color:#DEBA84;border-width:1px;border-style:None;font-size:big;height:50px;width:1100px;">
		<tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Own Playground</td><td>Yes</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Playground of another institution on sharing basis</td><td>No</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Gymnasium/Multipurpose hall</td><td>No</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Facilities for Gymnasium</td><td>Yes</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Facilities for Athletics</td><td>Yes</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Facilities for Indoor Games</td><td>Yes</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Facilities for Outdoor Games</td><td>Yes</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Canteen Facilities available or not</td><td>Yes</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Medical Facilities available or not</td><td>Yes</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Hostel Facilities available or not</td><td>No</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Student Satisfaction Survey</td><td>Yes</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Teacher Satisfaction Survey</td><td>Yes</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Parent Satisfaction Survey</td><td>Yes</td>
		</tr>
	</table>
</div>
                        <br />
                        
      <br>
      <br>
      
    </div>

        </div>
        
</td></tr>
                
			</table>
		
        		<br><br>
        	<br>
        	
        <br>	
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
