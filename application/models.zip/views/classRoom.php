<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	<BR>
        	<BR>
        	  <h1 style="margin-left:7em;">Detail of class Rooms</h1>

<BR>
<BR>
<table cellspacing="2" cellpadding="3" rules="all" id="ContentPlaceHolder1_GridView1" style="font-size:big;width:1100px; text-align:center;">
		<tr style="color:White;background-color:#A55129;font-weight:bold;">
			<th scope="col">S.no.</th><th scope="col">Particulars</th><th scope="col">No Of Room </th><th scope="col">Size in Fit </th>
		</tr>
		<tr>
    <td  width="163">1</td>
    <td width="197" >class Rooms </td>
    <td  width="251">8</td>
    <td width="258">20x25</td>
  </tr>
  <tr>
    <td >2</td>
    <td>Computer Lab</td>
    <td >1</td>
    <td>25x40</td>
  </tr>
  <tr>
    <td >3</td>
    <td>Library</td>
    <td >1</td>
    <td>35x40</td>
  </tr>
  <tr>
    <td >4</td>
    <td>Math Lab</td>
    <td >1</td>
    <td>20x25</td>
  </tr>
  <tr>
    <td >5</td>
    <td>Physics Lab</td>
    <td >1</td>
    <td>25x40</td>
  </tr>
  <tr>
    <td >6</td>
    <td>Chemistry Lab</td>
    <td >1</td>
    <td>25x40</td>
  </tr>
  <tr>
    <td >7</td>
    <td>Biology Lab</td>
    <td >1</td>
    <td>25x40</td>
  </tr>
  <tr>
    <td >8</td>
    <td>Vacant Class Rooms</td>
    <td >13</td>
    <td>20x25</td>
  </tr>
  <tr>
    <td >9</td>
    <td>Activity/ Music Room</td>
    <td >1</td>
    <td>20X35</td>
  </tr>
  <tr>
    <td >10</td>
    <td>Staff Room</td>
    <td >1</td>
    <td>15x36</td>
  </tr>
  <tr>
    <td >11</td>
    <td>Sports Room</td>
    <td >1</td>
    <td>20x10</td>
  </tr>
		
	</table>
	
	
	<BR>
	<BR>
	<BR>
	<BR>
	<BR>
	<BR>
	<BR>
	
	</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
	