<?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
 <div class="wrapper"> 
    <div class="contentPane">
      <div class="contentPaneLt">
        <div class="cont_lt_col1">
          <div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/aboutus_txt.jpg" alt="">
            
          </div>
          <div class="breadcrumb"><a href="<?php echo base_url();?>" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">School</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> About us</div>
          <div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2> About Merry City School</h2></div> <div class="intContent"><span style="font-weight: bold;">Merry City School, Ghazipur</span> is the creation of some ambitious person with noble through to serve the nation through education . Merry City School started its journey in 1985 Mau Nath Bhanjan with 100 students reaching the strength of 2000 students. In 1997, Merry City School, Varanasi was launched to serve the society with 200 students but recently it is running with full capacity. On this side Merry City School, Ghazipur is going to launch a unique academic by bleding the mordern world and the traditional society so that it becomes a pioneering institution in varanasi.
            </div></div>
        </div>
      </div>
    <?php $this->load->view("pageSideBar");?>
    </div>
    <!--Content Pane--> 
  </div>
<?php $this->load->view("footer");?>