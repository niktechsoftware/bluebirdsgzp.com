<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	<br>
        	
        	
        	<table>
        	<tr>
         <td> 
         <h1 style="margin-left:7em;">General Rules</h1>
         <p  style="margin-left:5em;"> 1.All boys and girls are expected to take an active part in games, sports, debates, quiz competition and other co-curricular activities, in a pure team and
sportsman spirit.<br>
2. Computer Lab - A fully equipped computer lab with the latest machines and qualified teachers is available in the school for practical classes and better
understanding of the students.<br>
3. Playground - The school has its own play ground which can accommodate all the students at a time and is sufficient to provide the students with sporting
atmosphere along with the studies.<br>
4. Students are learning through Smart Classes.<br>
         
        6. There will be four formative assessments and two summative assessments for continuous curriculum.<br>
7. The final assessment of the pupil at the end of the academic year shall be based on his/her total achievements.<br>
8. A pupil has to appear in the annual examination even though he/she had secured sufficient marks in periodical tests and half yearly examination or else
will be deemed to have failed in the annual examination, and shall not be promoted to the next higher class. However, if the absence from the annual
examination was due to reasons beyond control of the pupil, he/she may be given promotion to the next class on the recommendation of Principal and
Managing Committee if he/she had passed in all other tests and Half yearly examination.<br>
         9. A pupil will be eligible to appear in the Annual Examination if he/she has put in a minimum of 80% of the total attendance.<br>
10. Leave to the pupil for absence is granted only on an application addressed to the Principal through class teacher submitted in time (definitely the same
day or the next day in unavoidable circumstances) duly attested by the parent/guardian.<br>
11. The period of leave with reason should also be recorded in the pupil's diary by the parent with signature.<br>
12. In case of illness, a Medical Certificate must be attached with the application. Long absence except in case of illness will not be granted normally.<br>
13. If pupil is absent from the school for three consecutive days from the day of reopening, without forwarding a leave application in writing his/her name will
be struck off the rolls. If pupil is absent from the school for ten consecutive days without leave application his/her name will be removed from the school
rolls.</p>
</td></tr>
<tr><td><p style="margin-left:35em; ">Chairman<br> Blue Birds International School</p></td></tr>
                
			</table>
		
        	
        	
        		
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
