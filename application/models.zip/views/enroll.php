<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	<br>
        	<br>
        
        	<table>
        	<tr>
         <td> 
         <h1 style="margin-left:7em;">enrollment & result</h1>
         
         
         
         
         
         
         
         
         <br>
         
         
         
    <div>
    <table class="style1">
                            <tr> <td class="style3" style="text-align: center">
                               <table cellspacing="2" cellpadding="3" rules="all" id="ContentPlaceHolder1_GridView1" style="background-color:#DEBA84;border-color:#DEBA84;border-width:1px;border-style:None;font-size:big;width:1100px;">
		<tr style="color:White;background-color:#A55129;font-weight:bold;">
			<th scope="col">Class</th><th scope="col">Boys</th><th scope="col">Girls</th><th scope="col">Total</th>
		</tr>
		<tr style="color:#8C4510;background-color:#e5e7f8;">	<td>1</td><td>-</td><td>-</td><td>-</td></tr>
		<tr style="color:#8C4510;background-color:#e5e7f8;">	<td>2</td><td>-</td><td>-</td><td>-</td></tr>
			<tr style="color:#8C4510;background-color:#e5e7f8;"><td>3</td><td>-</td><td>-</td><td>-</td></tr>
		<tr style="color:#8C4510;background-color:#e5e7f8;">	<td>4</td><td>-</td><td>-</td><td>-</td></tr>
			<tr style="color:#8C4510;background-color:#e5e7f8;"><td>5</td><td>-</td><td>-</td><td>-</td></tr>
			<tr style="color:#8C4510;background-color:#e5e7f8;"><td>6</td><td>-</td><td>-</td><td>-</td></tr>
			<tr style="color:#8C4510;background-color:#e5e7f8;"><td>7</td><td>-</td><td>-</td><td>-</td></tr>
		<tr style="color:#8C4510;background-color:#e5e7f8;">	<td>8</td><td>-</td><td>-</td><td>-</td></tr>
			<tr style="color:#8C4510;background-color:#e5e7f8;"><td>Total</td><td>-</td><td>-</td><td>-</td>
			
		</tr>
	</table></td><br><br>
                            </tr>
                            <tr>
                                <td class="style3" style="text-align: center">
                                    <strong>Result in the Borad Examination for the last 3 year</strong></td>
                            </tr>
                            <tr>
                                <td>
                                    <div>

</div>
                                    <br />
                                    <br>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    
                                   
                                </td>
                            </tr>
                        </table>
    </div>

        </div>
         
</td></tr>
                
			</table>
		
        		<br><br>
        	<br>
        	
        <br>	
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
