<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	<br>
        	<br>
        
        	<table>
        	<tr>
         <td> 
         <h1 style="margin-left:7em;">Academic Session</h1>
         <p  style="margin-left:5em;"> School Calendar/Session :
The calendar of the school broadly follows the following schedule.</p><p style="margin-left:7em;">
a) The academic year is from April to March.</p><p style="margin-left:7em;">
b) Summer vacations are for nearly fifty days during May and June.</p><p style="margin-left:7em;">
c) Other holidays to be observed during the year are notified separately.</p>
</td></tr>
<tr>
         <td> 
         <h1 style="margin-left:7em;">विद्यालय  का सत्र कैलेन्डर </h1>
         <p  style="margin-left:5em;"> विद्यालय का सत्रकैलेन्डर निम्न्लिख्त का कार्यक्रमों का विवरण प्रस्तुत करता है |</p><p style="margin-left:7em;">
अ) शैक्षणिक वर्ष अप्रैल से मार्च तक |</p><p style="margin-left:7em;">
ब) ग्रीष्मवकाश लगभग 50 दिन मई और जून माह के अन्तेर्गत |</p><p style="margin-left:7em;">
स) अन्य अवकाश शैक्षणिक वर्ष के अन्तगर्त अलग से उल्लिखित किया गया है |</p>
</td></tr>
                
			</table>
		
        		<br><br>
        	<br>
        	
        <br>	
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
