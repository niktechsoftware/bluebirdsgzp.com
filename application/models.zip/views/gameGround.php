<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	<br>
        	<br>
        
        	<table>
        	<tr>
         <td> 
         <h1 style="margin-left:7em;">GAMES & SPORTS EQUIPMENTS</h1>
      
</td></tr>

<BR>
<BR>

 
    <div>
     <div>
	<table cellspacing="2" cellpadding="3" rules="all" id="ContentPlaceHolder1_GridView1" style="background-color:#DEBA84;border-color:#DEBA84;border-width:1px;border-style:None;font-size:big;width:1100px;">
		<tr style="color:White;background-color:#A55129;font-weight:bold;">
			<th scope="col">SNO.</th><th scope="col">Particular</th><th scope="col">Quantity</th>
		</tr>
		<tr style="color:#8C4510;background-color:#e5e7f8;">	<td>1</td><td>Volley ball</td><td>6</td></tr>
		<tr style="color:#8C4510;background-color:#e5e7f8;">	<td>2</td><td>Volley ball Net</td><td>4</td></tr>
			<tr style="color:#8C4510;background-color:#e5e7f8;"><td>3</td><td>Cricket Bat</td><td>4</td></tr>
		<tr style="color:#8C4510;background-color:#e5e7f8;">	<td>4</td><td>Stump</td><td>12</td></tr>
			<tr style="color:#8C4510;background-color:#e5e7f8;"><td>5</td><td>Batting Pad</td><td>8</td></tr>
			<tr style="color:#8C4510;background-color:#e5e7f8;"><td>6</td><td>Ball</td><td>12</td></tr>
			<tr style="color:#8C4510;background-color:#e5e7f8;"><td>7</td><td>Football</td><td>4</td></tr>
		<tr style="color:#8C4510;background-color:#e5e7f8;">	<td>8</td><td>Handball</td><td>4</td></tr>
			<tr style="color:#8C4510;background-color:#e5e7f8;"><td>9</td><td>Badminton Rackets (big)</td><td>4</td>
			
		</tr>
		<tr style="color:#8C4510;background-color:#e5e7f8;"><td>10</td><td>Batminton Rackets (small)</td><td>8</td>
			
		</tr>
		<tr style="color:#8C4510;background-color:#e5e7f8;"><td>11</td><td>Shuttle</td><td>24</td>
			
		</tr>
		<tr style="color:#8C4510;background-color:#e5e7f8;"><td>12</td><td>Badminton Net</td><td>4</td>
			
		</tr>
		<tr style="color:#8C4510;background-color:#e5e7f8;"><td>13</td><td>Carom Board</td><td>8</td>
			
		</tr>
		<tr style="color:#8C4510;background-color:#e5e7f8;"><td>14</td><td>Chess</td><td>10</td>
			
		</tr>
	</table>
</div>
                
			</table>
		
        		<br><br>
        		<BR>
        		<BR>
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
