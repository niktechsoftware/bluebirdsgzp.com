<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	<br>
        	<br>
        
        	<table>
        	<tr>
         <td> 
         <h1 style="margin-left:7em;">contact info</h1>
         
         
         
         <table id="table3" border="0" cellpadding="0" cellspacing="0" height="283" 
                                        width="100%">
                                        <tr>
                                            <td class="style11">&nbsp;
                                                </td>
                                            <td width="331" class="style14">
                                                <font color="#000066" size="2" class="style14">Blue Birds international School<br />
                                               </font></td>
                                        </tr>
                                      
                                        <tr>
                                            <td class="style22">
                                                </td>
                                            <td width="331" class="style23">
                                                <span class="style5"><strong>ADDRESS :</strong>&nbsp;</span><span class="style1"><span 
                                                    class="style5">Blue Birds international School<br />
                                               Misrawaliya, rauza</span></span><span 
                                                    class="style12">,Ghazipur, U.P.</span></td>
                                        </tr>
                                        <tr>
                                            <td class="style19">
                                                </td>
                                            <td width="331" class="style18">
                                                <strong>Ph:</strong>9455774866 (Sandeep Mishra)</td>
                                        </tr>
                                      
                                        <tr>
                                            <td height="19" class="style11">&nbsp;
                                                </td>
                                            <td height="19" width="331" class="style10">
                                                <strong>Ph:</strong>9565093866</td>
                                        </tr>
                                        <tr>
                                            <td class="style20">
                                                </td>
                                            <td width="331" class="style21">
                                                <strong>E-mail :</strong> 
                                               info@blubirdsgzp.com</span></font></td>
                                        </tr>
                                        <tr>
                                            <td height="20" class="style11">&nbsp;
                                                </td>
                                            <td height="20" width="331" class="style10">
                                                <strong>Website :</strong> www.bluebirdsgzp.com</td>
                                        </tr>
                                    </table>
</div>

        </div>
   
         
    </div>
    
         
        
</td></tr>
                
			</table>
		
        		<br><br>
        	<br>
        	<br>
        	<br>
        	<br>
        	<br>
        	<br>
        	
        <br>	
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
