<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	<br>
        	<br>
        
        	<table>
        	<tr>
         <td> 
         <h1 style="margin-left:7em;">mode of payment</h1>
         
           <br>
        <br>
        <br>
        <br>
          <div style="margin-left:40px">
     <div>
	<table cellspacing="2" cellpadding="3" rules="all" id="ContentPlaceHolder1_DetailsView1" style="background-color:#DEBA84;border-color:#DEBA84;border-width:1px;border-style:None;height:50px;width:593px;">
<tr><th>ECS</th></tr>
	</table>
</div>
                        <br />
                        
        <br>
            <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        
        
    </div>

        </div>
   
         
    </div>
    

         
         
</td></tr>
                
			</table>
		
        		<br><br>
        	<br>
        	
        <br>	
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
