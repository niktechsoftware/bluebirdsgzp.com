<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	<br>
        	<br>
        
        	<table>
        	<tr>
         <td> 
         <h1 style="margin-left:7em;">Building</h1>
         
         
         
         
         
         
         
          
    <div>
     <div>
	<table cellspacing="2" cellpadding="3" rules="all" id="ContentPlaceHolder1_DetailsView1" style="background-color:#DEBA84;border-color:#DEBA84;border-width:1px;border-style:None;font-size:big;height:50px;width:1100px;">
		<tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Construction of building is completed</td><td>Yes</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Building is yet to be constructed</td><td>No</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Building is fire safety-proof</td><td>Yes</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Building is disabled friendly</td><td>Yes</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Common room for boys/girls available</td><td>Yes</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Date of completion of the building</td><td>-</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Covered area in first floor sq meter</td><td>1121</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Open Field Area in Sq meter</td><td>4566.26</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>The library has separate refrence section/Journals section and reading room</td><td>Yes</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Number of books in library</td><td>2521</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Total number of educational Journal/periodicals being subscribed</td><td>18</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Number of encyclopedias available in library</td><td>30</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Number of books available in the refrence section of the library</td><td>129</td>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Seating capacity of the reading room of library</td><td>60</td>
		</tr>
	</table>
</div>
                        <br />
                        
        <br />
        <br />
      
 
        
        
    </div>

        </div>
   
         
    </div>
         
</td></tr>
                
			</table>
		
        		<br><br>
        	<br>
        	
        <br>	
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
