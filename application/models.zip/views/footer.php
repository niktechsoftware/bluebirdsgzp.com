		


<script type="text/javascript" src="<?php echo base_url();?>assets/javascripts/jquery.tools.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/javascripts/jquery.easing.1.3.js"></script>

<!-- include Cycle2 -->
<script src="<?php echo base_url();?>assets/javascripts/jquery.cycle2.min.js"></script>

<!-- include one or more optional Cycle2 plugins -->
<script src="<?php echo base_url();?>assets/javascripts/jquery.cycle2.carousel.min.js"></script>  
            
   <!--  / footer container \ -->
        <footer id="footerCntr">
        	
            <div class="container">
             	   
                <address>
                <strong>BLUE BIRD'S INTERNATIONAL SCHOOL</strong>
                Adarsh Bazar, Ghazipur-233001<br>
               
                    Contact : 09455774866, 09565093866 <br>
                    Email: info@bluebirds.com
                </address>        
                <ul>
                    <li><a target="_blank" href="#"><i class="fa fa-facebook"></i></a></li>
                    <li class="youtube"><a target="_blank" href="#"><i class="fa fa-youtube"></i></a></li>
                </ul> 
                
            </div>

        </footer>
        <!--  \ footer container / -->
    
    </div>
    <!--  \ main container / -->

</div>



</body>

</html> 
