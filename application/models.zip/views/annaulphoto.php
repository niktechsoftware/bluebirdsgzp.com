<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">
				
        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        
        <img src="<?php echo base_url();?>assets/images/commingsoon.jpg" alt="About Blue Birds International School" height="600" width="1100" title="Blue thoughts in a Blue environs"  >
    
        	<table>
        	<tr>
         <td> 
         <h1 style="margin-left:7em;">Comming Soon...</h1>
       
</td></tr>
                
			</table>
		
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
