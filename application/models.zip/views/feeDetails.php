<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	<br>
        	<br>
        
        	<table>
        	<tr>
         <td > 
         <h1 style="margin-left:7em;">Fee structure</h1>
         <p  style="margin-left:5em;"> <h3>School Calendar/Session :
The calendar of the school broadly follows the following schedule.</h3></p>
<table style="margin-left:15em;">	
<tr>	<td>cost oF form/Ragistration fee</td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>		                                    <td>100/-</td>		</tr>
<tr>	<td>Admission Fee </td>		<td>&nbsp;-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>												    <td>500/-</td>		</tr>
<tr>	<td>Amminity Charges (Annual) </td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>												<td></td>		</tr>
<tr>	<td>I-Card</td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>																	<td>25/-</td>		</tr>
<tr>	<td>diary</td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>																	<td>50/-</td>		</tr>
<tr>	<td>Tution Fee</td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>																<td></td>		</tr>
<tr>	<td>VII TO VIII</td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>															<td>400/-</td>		</tr>
<tr>	<td>Computer</td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>																<td>500/-</td>		</tr>
<tr>	<td>Transport 0 To 5Km </td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>													<td>100/-</td>		</tr>
<tr>	<td>diary</td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>																	<td>300/-</td>		</tr>

</table>
</td></tr>

<tr>
         <td> 
         <h1 style="margin-left:7em;">फी  स्ट्रक्चर </h1>
<table style="margin-left:15em;">	
<tr>	<td>  कास्ट ऑफ फॉर्म /रजिस्ट्रेशन  फीस</td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>		                                            <td>100/-</td>		</tr>
<tr>	<td>प्रवेश फी </td>		<td>&nbsp;-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>															<td>500/-</td>		</tr>
<tr>	<td>अमेनिटी चार्जेज </td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>												                <td></td>		</tr>
<tr>	<td>परिचय पत्र</td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>																	<td>25/-</td>		</tr>
<tr>	<td>डायरी</td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>																	    <td>50/-</td>		</tr>
<tr>	<td>ट्युशन  फीस </td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>																    <td></td>		</tr>
<tr>	<td>पीजी से  कक्षा  5</td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>															    <td>400/-</td>		</tr>
<tr>	<td>कक्षा  6 से  8</td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>																    <td>500/-</td>		</tr>
<tr>	<td>कंप्यूटर  </td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>													                <td>100/-</td>		</tr>
<tr>	<td>ट्रांसपोर्ट  0 To 5किमी</td>		<td>-&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>															<td>300/-</td>		</tr>

</table>





</td></tr>
                
			</table>
		
        		<br><br>	
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
