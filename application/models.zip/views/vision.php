<?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
 <div class="wrapper"> 
    <div class="contentPane">
      <div class="contentPaneLt">
        <div class="cont_lt_col1">
          <div class="inHeadimg"> <img src="<?php echo base_url();?>assets/images/vision_txt.jpg" alt="">
            
          </div>
          <div class="breadcrumb"><a href="<?php echo base_url();?>" title="">Home</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> <a href="#">School</a> <span><img src="<?php echo base_url();?>assets/images/brdcrumb-arrw.png" alt="" /></span> Vision</div>
          <div id="ctl00_ContentPlaceHolder1_visitText"><div class="int-title"> <h2> About Merry City School</h2></div> <div class="intContent"><span style="font-weight: bold;"></span>
          <ul>
            <li>The institute that stand out is established through people have ideas, thoughts, creativity and above all vision.</li>
              <li>The behind this institute have a vision to createMerry City School, Ghazipur a vibrant learning organization in the field of education. </li>
          </ul>
          
            </div></div>
        </div>
      </div>
    <?php $this->load->view("pageSideBar");?>
    </div>
    <!--Content Pane--> 
  </div>
<?php $this->load->view("footer");?>