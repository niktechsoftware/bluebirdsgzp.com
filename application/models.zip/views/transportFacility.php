<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	<br>
        	<br>
        	<br>
        	<br>
        	<br>
        
        	<table>
        	<tr>
         <td> 
         <h1 style="margin-left:7em;">Academic Session</h1>
         
         
         <br>
         <br>
         <br>
         
          <div>
    <table cellspacing="2" cellpadding="3" rules="all" id="ContentPlaceHolder1_DetailsView1" style="background-color:#DEBA84;border-color:#DEBA84;border-width:1px;border-style:None;font-size:big;height:50px;width:1000px;">
		
			
		<tr style="color:#8C4510;background-color:#e5e7f8;font-weight:bold;">
			<td>Transport facility</td><td> Yes</td>
		</tr>
	</table>
         </div>

        </div>
   
         
    </div>
    <br>
    <br>
    <br>
    <br>
</td></tr>
                
			</table>
		
        		<br><br>
        	<br>
        	
        <br>	
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
