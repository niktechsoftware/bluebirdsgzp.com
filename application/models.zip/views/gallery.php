<?php $this->load->view("header");?>
<?php $this->load->view("menu");?>
 <div class="wrapper"> 
    <div class="contentPane" style="border: 1px solid">
    <div class="image-row">
				<div class="image-row">
				<div class="image-set" >
					<a class="example-image-link" href="<?php echo base_url();?>assets/gallery/gal/1.jpg" data-lightbox="example-set" data-title="welcome."><img class="example-image" src="<?php echo base_url();?>assets/gallery/gal/1.jpg" alt="" style="width:218px; height:218px;padding: 10px;"/></a>
					<a class="example-image-link" href="<?php echo base_url();?>assets/gallery/gal/2.jpg" data-lightbox="example-set" data-title="welcome"><img class="example-image" src="<?php echo base_url();?>assets/gallery/gal/2.jpg" alt="" style="width:218px; height:218px;padding: 10px;" /></a>
					<a class="example-image-link" href="<?php echo base_url();?>assets/gallery/gal/3.jpg" data-lightbox="example-set" data-title="welcome."><img class="example-image" src="<?php echo base_url();?>assets/gallery/gal/3.jpg" alt="" style="width:218px; height:218px;padding: 10px;"/></a>
					<a class="example-image-link" href="<?php echo base_url();?>assets/gallery/gal/4.jpg" data-lightbox="example-set" data-title="welcome"><img class="example-image" src="<?php echo base_url();?>assets/gallery/gal/4.jpg" alt="" style="width:218px; height:218px;padding: 10px;" /></a>
				    <a class="example-image-link" href="<?php echo base_url();?>assets/gallery/gal/4.jpg" data-lightbox="example-set" data-title="welcome."><img class="example-image" src="<?php echo base_url();?>assets/gallery/gal/5.jpg" alt="" style="width:218px; height:218px;padding: 10px;"/></a>
					<a class="example-image-link" href="<?php echo base_url();?>assets/gallery/gal/6.jpg" data-lightbox="example-set" data-title="welcome"><img class="example-image" src="<?php echo base_url();?>assets/gallery/gal/6.jpg" alt="" style="width:218px; height:218px;padding: 10px;" /></a>
					<a class="example-image-link" href="<?php echo base_url();?>assets/gallery/gal/7.jpg" data-lightbox="example-set" data-title="welcome"><img class="example-image" src="<?php echo base_url();?>assets/gallery/gal/7.jpg" alt="" style="width:218px; height:218px;padding: 10px;" /></a>
					<a class="example-image-link" href="<?php echo base_url();?>assets/gallery/gal/8.jpg" data-lightbox="example-set" data-title="welcome"><img class="example-image" src="<?php echo base_url();?>assets/gallery/gal/8.jpg" alt="" style="width:218px; height:218px;padding: 10px;" /></a>
					
				</div>
			</div>
			</div>
   
    </div>
    <!--Content Pane--> 
  </div>
<?php $this->load->view("footer");?>