<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	<br>
        	<br>
        
        	<table>
        	<tr>
         <td> 
         <h1 style="margin-left:7em;">SCHOOL OF LIABERY BOOK</h1>
         
         <table cellspacing="2" cellpadding="3" rules="all" id="ContentPlaceHolder1_GridView1" style="font-size:big;width:1100px; text-align:center;">
		<tr style="color:White;background-color:#A55129;font-weight:bold;">
			<th scope="col">S.no.</th><th scope="col">Head</th><th scope="col">No Of Books </th>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>1</td><td>Reference Book</td><td>129 </td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>2</td><td>NCERT Books(1 To 10)</td><td>270</td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>3</td><td>CBSC (Curriculum, CCE, Teachers Manual, Marketing Scheme etc)</td><td>75</td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>4</td><td>Story Books(Hindi & English)</td><td>522</td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>5</td><td>Music</td><td>139</td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>6</td><td>G.K Book</td><td>211</td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>7</td><td>Moral Value</td><td>1157</td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>8</td><td>Subjective Book</td><td>2521</td>
		</tr>
		
	</table>
</div>
                      
                        
                        
                        
                         <div class="style3"><H1>List Of Gournals, Periodicals & Magazines</H1>
    </div><br />
    
    <div>
    
     <div>
	<table cellspacing="2" cellpadding="3" rules="all" id="ContentPlaceHolder1_GridView1" style="font-size:big;width:1100px; text-align:center;">
		<tr style="color:White;background-color:#A55129;font-weight:bold;">
			<th scope="col">S.no.</th><th scope="col">Title</th><th scope="col">Quantity </th>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>1</td><td>COMPUTER CAREER</td><td>2 </td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>2</td><td>COMICS</td><td>5</td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>3</td><td>VIGYANPRAGATI</td><td>4</td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>4</td><td>GYAN DARSHIKA</td><td>2</td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>5</td><td>ENGLISH TODAY</td><td>2</td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>6</td><td>CRICKET TODAY</td><td>2</td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>7</td><td>INDIA TODAY</td><td>4</td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>8</td><td>PRATIYOGITA DARPAN</td><td>4</td>
		
	
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>9</td><td>SAMANYA GYAN DARPAN</td><td>4</td>
		
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>10</td><td>SCIENCE QUIZ</td><td>4</td>
		
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>11</td><td>CHAMPAK</td><td>3</td>
		
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>12</td><td>NANHE SAMRAT</td><td>3</td>
		
		</tr>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>13</td><td>NANDAN</td><td>3</td>
		
		</tr>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>14</td><td>BAL HANS</td><td>3</td>
		
		</tr>
	</table>
</div>
                        
                          
        
        
        
         <div class="style3"><H1>LIST OF NEW PAPER</H1>
    </div><br />
    
    <div>
    
     <div>
	<table cellspacing="2" cellpadding="3" rules="all" id="ContentPlaceHolder1_GridView1" style="font-size:big;width:1100px; text-align:center;">
		<tr style="color:White;background-color:#A55129;font-weight:bold;">
			<th scope="col">S.no.</th><th scope="col">Title</th><th scope="col">Quantity </th>
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>1</td><td>TIMES OF INDIA</td><td>2 </td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>2</td><td>HINDUSTAN TIMES</td><td>2</td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>3</td><td>AMAR UJALA</td><td>2</td>
		
		</tr><tr style="color:#8C4510;background-color:#e5e7f8;">
			<td>4</td><td>DAINIK JAGRAN</td><td>2</td>
		
		
		
		</tr>
	</table>
         
         
         
        
</td></tr>
                
			</table>
		
        		<br><br>
        	<br>
        	
        <br>	
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
