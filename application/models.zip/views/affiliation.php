<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	<br>
        	<br>
        
        	<table>
        	<tr>
         <td> 
         <h1 style="margin-left:7em;">Affiliation Info</h1>
         
         
         <br>
        	<br>
        <div>
      <div>
	<table cellspacing="2" cellpadding="3" rules="all" id="ContentPlaceHolder1_DetailsView1" style="background-color:#DEBA84;border-color:#DEBA84;border-width:1px;border-style:None;font-size:Small;height:50px;width:609px;">
		<tr>
		<td><h2>Affiliated By Central Board of Secondary Education </h2> 
		</td>
		</tr>
		<tr>
		<td><h2>CBSE Affiliation Number : 2132251  </h2>
		</td>
		</tr>
	</table>
</div>
                      
         
        	            
        
    </div>

        </div>
   
         
    </div>
         
</td></tr>
                
			</table>
		
        		<br><br>
        	
        	<br>
        	<br
        	<br>
        	<br>
        	<br>
        	<br>
        	<br>
        	<br
        	<br>
        	<br>
        <br>	
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
