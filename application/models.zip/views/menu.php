 <div class="menuBox home"  id="nav">
        	<div class="container">

                <ul>
                                    <li><a href="<?php echo base_url();?>index.php/welcome/index">HOME</a></li>
                                    <li><span>ABOUT US</span>
                                    
                                    	<ul>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/aboutschool">ABOUT SCHOOL</a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/vissionmisshion">VISSION & MISSION</a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/directordesk">DIRECTOR'S DESK</a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/genInstruction">GENERAL INSTRUCTIONS</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                    	<span>ACADEMIC</span>
                                        
                                        <ul>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/academicSession">ACADEMIC SYSTEM</a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/admissionpro">ADMISSION PROCEDURE </a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/transferCertificate">TRANSFER CERTIFICATE </a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/curriculum">CURRICULUM </a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/feeDetails">FEE DETAILS </a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/cce">CCE </a></li>
                                        </ul>
                                    
                                    </li>
                                     <li>
                                    	<span>CAMPUS</span>
                                        
                                        <ul>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/classRoom">CLASS ROOM</a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/schoolLibrary">SCHOOL LIBRARY </a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/schoolBuilding">SCHOOL BUILDING </a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/gameGround">GAMES & GROUND </a></li>
                                        	
                                        </ul>
                                    
                                    </li>
                                    
                                     <li>
                                    	<span>PHOTO GALLERY</span>
                                        
                                        <ul>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/annaulphoto">ANNUAL FUNCTION</a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/sportphoto">SPORTS GALLERY </a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/otherphoto">OTHER GALLERY </a></li>
                                        	
                                        </ul>
                                    
                                    </li>
                                     <li>
                                    	<span>CBSE DETAILS</span>
                                        
                                        <ul>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/facilities">FACILITIES</a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/building">BUILDING </a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/landManagement">LAND & MANAGEMENT </a></li>
                                        	
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/financial">FINANCIAL STATUS</a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/feeStructure">FEE STRUCTURE </a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/infrastructure">INFRASTRUCTURE </a></li>
                                        	
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/enroll">ENROLLMENT & RESULT</a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/smcMember">SMC MEMBER DETAILS </a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/grievance">GRIEVANCE OFFICER </a></li>
                                        	
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/academicSession">ACADEMIC SESSION</a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/transportFacility">TRANSPORT FACILITY </a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/affiliation">AFFILIATION INFO </a></li>
                                        	
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/nocDetail">NOC DETAIL</a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/nof">NO. OF FACULTY </a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/modeOfPayment">MODE OF PAYMENT </a></li>
                                        </ul>
                                    
                                    </li>
                                    
                                   
                                   <li>
                                    	<span>CONTACT US</span>
                                        
                                        <ul>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/contactInfo">CONTACT INFO</a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/reachUs">HOW TO REACH </a></li>
                                        	<li><a href="<?php echo base_url();?>index.php/welcome/enquiry">ENQUIRY </a></li>
                                        	
                                        </ul>
                                    
                                    </li>
                                   <li><a href="#">Login</a></li>
                                </ul>

            </div>
        </div>