<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	<br>
        	<br>
        
        	<table>
        	<tr>
         <td> 
         <h1 style="margin-left:7em;">Noc detail</h1>
         
         
         
           <div>
     <div>
	<table cellspacing="2" cellpadding="3" rules="all" id="ContentPlaceHolder1_GridView1" style="background-color:#e5e7f8;border-color:#e5e7f8;border-width:1px;border-style:None;font-size:;width:1200px;">
		<tr style="color:White;background-color:#A55129;font-weight:bold;">
			<th scope="col">SNo</th><th scope="col">Name</th><th scope="col">Refence No</th><th scope="col">Date</th>
		</tr><tr style="color:#8C4510;background-color:#FFF7E7;">
			<td>1</td><td>BSA Ghazipur U.P</td><td>Noc.No- 34</td><td>11/04/2016</td>
		</tr>
	</table>
</div>
         
</td></tr>
                
			</table>
		
        		<br><br>
        	<br>
        	
        <br>
        <br>
        	
        <br>	<br>
        	
        <br>	<br>
        	
        <br>		
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
