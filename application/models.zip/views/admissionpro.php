<?php $this->load->view("header");?>
 <?php $this->load->view("menu");?>
<!--  / wrapper \ -->
<div id="wrapper" style="z-index: -90;">

    <!--  / main container \ -->
    <div id="mainCntr">

        <!--  / banner container \ -->
           	
        <div >
        	<div class="container">
        	
        	<table>
        	<tr>
         <td> 
         <h1 style="margin-left:7em;">Admission Rules :</h1>
         <p  style="margin-left:5em;"> 1. Admission test will be conducted by the school on the dates to be notified by the Principal.</p><p style="margin-left:5em;">
2. Admission will be allowed after a pupil qualifies the test and submits the Transfer certificate of the previous school along with the Progress Report of the
last examination passed.</p><p style="margin-left:5em;">
3. The admission test will be held in English, Hindi and Maths for classes P.G. to VI. Admission to Nursery will be made without any Test/Interview but
however parents are required to come along with the child at the time of Admission.</p><p style="margin-left:5em;">
4. The minimum age of the students seeking admission is 3 years for P.G., 4.5 years for LKG, 5 years for UKG and 5.5 years for class one and so on.
5. Birth Certificate issued by Municipalities/Village Panchayats will be accepted.</p><p style="margin-left:5em;">
6. Once recorded in the school Register, Change in the date of Birth will not be accepted.
         </p>
</td></tr>
<tr>
         <td> 
         <h1 style="margin-left:7em;">प्रवेश के नियम  </h1></p><p style="margin-left:5em;">
         
1) प्रवेश  प्रशिक्षण विद्यालय के प्रधानाचार्य द्वारा अग्रसरित तिथियों पर ही किया जायगा |</p><p style="margin-left:5em;">
2) प्रवेश की अनुमति की अनुमति तभी होगी जब छात्र परीक्षा में सफलता के अर्जित कर अपने पूर्व के विद्यालय से स्थानांतरण प्रमाण -पत्र के साथ आखरी परीक्षा उतीर्ण होने का अंक पत्र प्रस्तुत करेगा   |</p><p style="margin-left:5em;">
3) प्रवेश परीक्षा अंग्रेजी और गणित विषय में  कक्षा  पी.जी से  6 स्तर   तक की होगी   |नर्सरी में प्रवेश हेतु परिकक्षण  आवश्यक नही  है  परन्तु प्रवेश के समय बच्चे को  अपने आभिभावक के साथ होना आवश्यक है | </p><p style="margin-left:5em;">
4) पी .जी  में प्रवेश  हेतु बच्चे की नियुनतम उम्र 3 वर्ष,एल .केजी के लिए 4.5 वर्ष  तथा यू .केजी के लिए 5 वर्ष ,तथा कक्षा  1 के लिए 5.5 वर्ष  निरधारित है  |</p><p style="margin-left:5em;">
5) जन्म -प्रमाण  पत्र नगरपालिका या ग्राम पंचायत द्वारा अग्रसरित होने  पर  ही  स्वीकृत होगा  |</p><p style="margin-left:5em;">
6)एक बार जन्म की जन्म तिथि  छात्र पंजीका रजिस्टर मर दर्ज होने के पश्चात कोई परिवर्तन नही होगा   |</p>
</td></tr>
                
			</table>
		
        		
			</div>
        </div>
        <!--  \ value box / -->
						
       
        <!--  / events box \ -->
       
       <?php $this->load->view("footer")?>
